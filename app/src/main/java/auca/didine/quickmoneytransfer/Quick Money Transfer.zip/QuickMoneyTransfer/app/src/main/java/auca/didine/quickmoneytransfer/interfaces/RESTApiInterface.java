package auca.didine.quickmoneytransfer.interfaces;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RESTApiInterface {

    // create user
    @POST("register/")
    Call<ResponseBody> createUser(@Body Map<String,String> obj);



    // login user
    @POST("login/")
    Call<ResponseBody> loginUser(@Body Map<String,String> obj);



}
